#!/usr/bin/python
#coding=utf-8

# cgi/mysql/time mudole
import cgi, cgitb

cgitb.enable()

# db argument setting
db_host = 'localhost'
db_username = 'root'
db_password = '2167@nTuT'
db_name = 'habiture'

