#!/usr/bin/python
#coding=utf-8

# cgi/mysql/time mudole
import cgi, cgitb

cgitb.enable()

# database argument setting
db_host = 'localhost'
db_username = 'root'
db_password = '2167@nTuT'
db_name = 'habiture'

# gcm server key argument setting
SERVER_KEY = "AIzaSyD4I-Fnk_EsAgTQBZU-t8WKXZDV_6fI_M4"
